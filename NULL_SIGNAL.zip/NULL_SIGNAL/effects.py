"""Offline image operations. Intensities are 0–100; every render is seeded."""
from pathlib import Path
import os
import tempfile
import warnings

import numpy as np
from PIL import Image, ImageOps

EFFECTS = {
    'VHS': 'Scanlines / chromatic drift / tape noise',
    'STATIC': 'Monochrome grain / signal interference',
    'GLITCH': 'Displaced bands / RGB split / pixel slips',
    'GHOST FRAME': 'Offset exposure / residual image',
    'CCTV': 'Monochrome / contrast / lens falloff',
    'DISTORTION': 'Wave displacement / unstable geometry',
    'DARKROOM': 'Faded color / deep shadows / film grain',
}
FORMATS = {'.jpg': 'JPEG', '.jpeg': 'JPEG', '.png': 'PNG', '.bmp': 'BMP'}


def load_image(path):
    """Detach decoded pixels from the file; respect camera orientation."""
    path = Path(path)
    if path.suffix.lower() not in FORMATS:
        raise ValueError('Choose a JPG, JPEG, PNG or BMP image.')
    with warnings.catch_warnings():
        warnings.simplefilter('error', Image.DecompressionBombWarning)
        with Image.open(path) as source:
            if source.format not in set(FORMATS.values()):
                raise ValueError('The file contents are not a supported image format.')
            fmt = source.format
            source.load()
            image = ImageOps.exif_transpose(source).convert('RGBA')
    return image, fmt


def export_image(image, destination, original_path):
    """Write atomically; reject aliases of the original, including hard links."""
    target, source = Path(destination), Path(original_path)
    if target.resolve() == source.resolve() or (
        target.exists() and source.exists() and os.path.samefile(target, source)
    ):
        raise ValueError('The original is protected. Choose a different filename.')
    fmt = FORMATS.get(target.suffix.lower())
    if fmt is None:
        raise ValueError('Use a .png, .jpg, .jpeg or .bmp export filename.')
    output = image
    if fmt in ('JPEG', 'BMP'):
        rgba = image.convert('RGBA')
        output = Image.new('RGB', image.size, (0, 0, 0))
        output.paste(rgba, mask=rgba.getchannel('A'))
    fd, temporary = tempfile.mkstemp(prefix='.null-signal-', dir=target.parent)
    os.close(fd)
    try:
        output.save(temporary, format=fmt, **({'quality': 95} if fmt == 'JPEG' else {}))
        os.replace(temporary, target)
    finally:
        Path(temporary).unlink(missing_ok=True)


def _shift_rows(a, offsets):
    h, w = a.shape[:2]
    x = (np.arange(w)[None, :] - np.asarray(offsets, dtype=int)[:, None]) % w
    return a[np.arange(h)[:, None], x]


def _shift_rows_smooth(a, offsets):
    # Interpolate fractional shifts so low intensities also affect small images.
    h, w = a.shape[:2]
    x = (np.arange(w)[None, :] - offsets[:, None]) % w
    left = np.floor(x).astype(int)
    fraction = (x - left).astype(np.float32)[:, :, None]
    rows = np.arange(h)[:, None]
    return a[rows, left] * (1 - fraction) + a[rows, (left + 1) % w] * fraction


def _rgb_split(a, amount):
    b = a.copy()
    b[:, :, 0] = np.roll(a[:, :, 0], amount, axis=1)
    b[:, :, 2] = np.roll(a[:, :, 2], -amount, axis=1)
    return b


def _grain(a, rng, strength):
    return a + rng.normal(0, strength, (*a.shape[:2], 1)).astype(np.float32)


def apply_effect(image, name, intensity, seed=0):
    """Apply one effect to a copy, retaining dimensions and the alpha channel."""
    if name not in EFFECTS:
        raise ValueError(f'Unknown effect: {name}')
    t = float(intensity) / 100.0
    if not np.isfinite(t) or not 0 <= t <= 1:
        raise ValueError('Intensity must be between 0 and 100.')
    if t == 0:
        return image.copy()
    rgba = image.convert('RGBA')
    a = np.asarray(rgba, dtype=np.float32)[:, :, :3].copy()
    h, w = a.shape[:2]
    rng = np.random.default_rng(seed)
    y = np.arange(h, dtype=np.float32)
    pixel = max(1, round(w / 500))
    if name == 'VHS':
        offsets = np.sin(y * .055) * pixel * 2 * t
        a = _shift_rows(a, offsets)
        a = _rgb_split(a, max(1, round(pixel * 3 * t)))
        a[1::3] *= 1 - .32 * t
        a = _grain(a, rng, 12 * t)
        row = int(rng.integers(h))
        a[row:row + max(1, h // 80)] += 26 * t
    elif name == 'STATIC':
        a = _grain(a, rng, 48 * t)
        for _ in range(max(1, round(7 * t))):
            row = int(rng.integers(h))
            a[row:row + max(1, h // 180)] += rng.uniform(-90, 90) * t
    elif name == 'GLITCH':
        offsets = np.zeros(h, dtype=int)
        for _ in range(max(1, round(12 * t))):
            row = int(rng.integers(h))
            depth = int(rng.integers(1, max(2, h // 20)))
            offsets[row:row + depth] = int(rng.uniform(-.12, .12) * w * t)
        a = _rgb_split(_shift_rows(a, offsets), max(1, round(pixel * 6 * t)))
        for _ in range(max(1, round(5 * t))):
            x, row = int(rng.integers(w)), int(rng.integers(h))
            bw, bh = max(1, w // 12), max(1, h // 40)
            patch = a[row:row + bh, x:x + bw].copy()
            a[row:row + bh, x:x + bw] = np.roll(patch, pixel * 3, axis=1)
    elif name == 'GHOST FRAME':
        ghost = np.roll(a, max(1, round(w * .035 * t)), axis=1)
        a = a * (1 - .40 * t) + ghost * (.40 * t)
    elif name == 'CCTV':
        gray = a @ np.array([.299, .587, .114], dtype=np.float32)
        gray = (gray - 128) * 1.55 + 115
        yy = np.linspace(-1, 1, h, dtype=np.float32)[:, None]
        xx = np.linspace(-1, 1, w, dtype=np.float32)[None, :]
        gray *= np.clip(1 - .44 * (xx * xx + yy * yy), .18, 1)
        cctv = _grain(np.repeat(gray[:, :, None], 3, axis=2), rng, 13)
        cctv[::2] *= .78
        a = a * (1 - t) + cctv * t
    elif name == 'DISTORTION':
        phase = rng.uniform(0, 2 * np.pi)
        offsets = (np.sin(y * 2 * np.pi / max(1, h) * 3 + phase)
                   + .3 * np.sin(y * .14)) * w * .025 * t
        a = _shift_rows_smooth(a, offsets)
        rows = (np.arange(h) + (np.sin(np.arange(w) * .018) * h * .004 * t)[:, None].astype(int)) % h
        a = a[rows.T, np.arange(w)[None, :]]
    elif name == 'DARKROOM':
        luma = (a @ np.array([.299, .587, .114], dtype=np.float32))[:, :, None]
        faded = a * .35 + luma * .65
        faded = np.maximum(0, (faded - 128) * 1.18 + 108)
        faded *= np.array([1.06, .98, .87], dtype=np.float32)
        a = a * (1 - t) + _grain(faded, rng, 5) * t
    result = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))
    result.putalpha(rgba.getchannel('A'))
    return result


def process_image(image, settings, seed):
    result = image.copy()
    # Stable per-effect seeds keep disabled effects from changing later noise.
    for index, name in enumerate(EFFECTS):
        value = settings.get(name, 0)
        if value:
            result = apply_effect(result, name, value, seed + index * 1009)
    return result
