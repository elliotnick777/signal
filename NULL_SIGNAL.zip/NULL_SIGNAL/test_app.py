"""Run with python -m unittest -v. GUI tests use Qt's offscreen platform."""
import hashlib
import importlib.util
import os
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

import numpy as np
from PIL import Image
from effects import EFFECTS, apply_effect, export_image, load_image, process_image


class ImageTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.path = Path(self.folder.name)
        self.pixels = np.random.default_rng(19).integers(0, 256, (63, 97, 4), dtype=np.uint8)
        self.image = Image.fromarray(self.pixels)
        self.source = self.path / 'source.png'
        self.image.save(self.source)

    def test_all_effects(self):
        for size in [(1, 1), (1, 15), (17, 1), self.image.size]:
            source = self.image.resize(size)
            unchanged = source.tobytes()
            for name in EFFECTS:
                for intensity in (0, 1, 50, 100):
                    with self.subTest(name=name, intensity=intensity, size=size):
                        output = apply_effect(source, name, intensity, 42)
                        self.assertEqual(output.size, size)
                        self.assertEqual(output.mode, 'RGBA')
                        self.assertEqual(output.getchannel('A').tobytes(), source.getchannel('A').tobytes())
                        self.assertEqual(output.tobytes(), apply_effect(source, name, intensity, 42).tobytes())
                        if intensity == 0:
                            self.assertEqual(output.tobytes(), unchanged)
                        elif size == self.image.size:
                            self.assertTrue(output.tobytes() != unchanged, 'Effect did not change pixels')
            self.assertEqual(source.tobytes(), unchanged)

    def test_chain_and_seed(self):
        settings = dict.fromkeys(EFFECTS, 60)
        output = process_image(self.image, settings, 78)
        self.assertEqual(output.tobytes(), process_image(self.image, settings, 78).tobytes())
        self.assertNotEqual(output.tobytes(), process_image(self.image, settings, 79).tobytes())
        self.assertEqual(self.image.tobytes(), self.pixels.tobytes())
        self.assertEqual(process_image(self.image, {}, 1).tobytes(), self.image.tobytes())

    def test_formats_and_export(self):
        original_hash = hashlib.sha256(self.source.read_bytes()).digest()
        output = process_image(self.image, {'VHS': 70}, 55)
        for ext in ('png', 'jpg', 'jpeg', 'bmp'):
            destination = self.path / ('export.' + ext)
            export_image(output, destination, self.source)
            decoded, fmt = load_image(destination)
            self.assertEqual(decoded.size, output.size)
            if ext == 'png':
                self.assertEqual(decoded.tobytes(), output.tobytes())
            self.assertIn(fmt, ('PNG', 'JPEG', 'BMP'))
        self.assertEqual(original_hash, hashlib.sha256(self.source.read_bytes()).digest())

    def test_invalid_files_and_destinations(self):
        bad = self.path / 'bad.png'
        bad.write_bytes(b'not image data')
        for path in (bad, self.path / 'missing.png', self.path / 'unsupported.gif'):
            with self.assertRaises(Exception):
                load_image(path)
        with self.assertRaises(ValueError):
            export_image(self.image, self.source, self.source)
        for name in ('alias.png', 'hardlink.png'):
            alias = self.path / name
            try:
                if name.startswith('alias'):
                    alias.symlink_to(self.source)
                else:
                    os.link(self.source, alias)
            except OSError:
                continue  # Windows may not grant symlink creation privileges.
            with self.assertRaises(ValueError):
                export_image(self.image, alias, self.source)
        for target in (self.path / 'x.gif', self.path / 'missing' / 'x.png'):
            with self.assertRaises((ValueError, OSError)):
                export_image(self.image, target, self.source)
        with self.assertRaises(ValueError):
            apply_effect(self.image, 'VHS', -1)


@unittest.skipUnless(importlib.util.find_spec('PySide6'), 'PySide6 is not installed')
class GuiTests(unittest.TestCase):
    setUp = ImageTests.setUp

    def test_window_workflow(self):
        os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
        from PySide6.QtWidgets import QApplication
        from main import MainWindow, STYLE
        app = QApplication.instance() or QApplication([])
        app.setStyleSheet(STYLE)
        window = MainWindow()
        window.show()

        def wait_idle():
            deadline = time.monotonic() + 20
            while window.worker is not None or window.debounce.isActive() or window.pending:
                app.processEvents()
                if time.monotonic() > deadline:
                    self.fail('Background operation timed out')
                time.sleep(.01)
            app.processEvents()

        try:
            app.processEvents()
            self.assertTrue(window.isVisible())
            with patch('main.QMessageBox.information') as notice:
                window.request_render()
                notice.assert_called_once()
            window.load_path(str(self.source))
            wait_idle()
            self.assertEqual(window.original.size, self.image.size)
            for name in EFFECTS:
                window.set_controls({name: 65})
                wait_idle()
                self.assertEqual(window.rendered_revision, window.revision)
                self.assertNotEqual(window.processed.tobytes(), window.original.tobytes())
            window.randomize()
            wait_idle()
            self.assertIn(sum(v > 0 for v in window.settings().values()), (2, 3, 4))
            before = window.processed.tobytes()
            window.request_render()
            wait_idle()
            self.assertEqual(before, window.processed.tobytes())
            window.before_button.click()
            window.after_button.click()
            window.preview.zoom(1.25)
            window.preview.fit_image()
            target = self.path / 'gui-export.png'
            with patch('main.QFileDialog.getSaveFileName', return_value=(str(target), 'PNG (*.png)')):
                window.choose_export()
                wait_idle()
            self.assertEqual(load_image(target)[0].tobytes(), window.processed.tobytes())
            window.reset()
            wait_idle()
            self.assertEqual(window.original.tobytes(), window.processed.tobytes())
            with patch('main.QMessageBox.warning') as warning:
                window.load_path(str(self.path / 'missing.png'))
                wait_idle()
                warning.assert_called_once()
            window.grab().save(str(self.path / 'window.png'))
        finally:
            wait_idle()
            window.close()
            app.processEvents()


if __name__ == '__main__':
    unittest.main()
