"""NULL//SIGNAL — a small, offline analog image editor."""
import random
import sys
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QApplication, QButtonGroup, QCheckBox, QFileDialog, QFrame,
    QGraphicsScene, QGraphicsView, QHBoxLayout, QLabel, QMainWindow,
    QMessageBox, QPushButton, QScrollArea, QSlider, QSplitter,
    QVBoxLayout, QWidget,
)
from effects import EFFECTS, export_image, load_image, process_image

VERSION = '1.0.0'
MESSAGES = [
    'IMAGE INTEGRITY: COMPROMISED', 'THE SIGNAL IS STILL ACTIVE.',
    'MEMORY FRAGMENT 004', 'DO NOT TRUST THE PREVIEW.',
    'SUBJECT RECOGNITION FAILED.', 'NO SOURCE FOUND.',
    'THE FRAME WAS NEVER EMPTY.', 'REALITY INPUT DETECTED.',
]
QUOTES = [
    'The image remembers what you forgot.',
    'An error is also a form of memory.',
    'Some signals have no sender.',
    'Not everything inside the frame belongs there.',
]
STYLE = '''
QWidget { background: #101112; color: #bdbdb4; font-family: "Consolas", "DejaVu Sans Mono", monospace; font-size: 12px; }
QMainWindow { background: #0b0c0d; }
QFrame#panel { background: #171819; border: 1px solid #323334; }
QLabel { background: transparent; border: none; }
QLabel#logo { color: #dddcd1; font-size: 25px; font-weight: bold; letter-spacing: 2px; }
QLabel#muted { color: #787b78; font-size: 11px; }
QLabel#red { color: #c17a74; }
QPushButton { background: #202223; border: 1px solid #494a47; padding: 10px 12px; text-align: left; }
QPushButton:hover { background: #2b2d2d; border-color: #8a8b7e; }
QPushButton:pressed, QPushButton:checked { background: #3a2928; border-color: #a36660; color: #e3d5cd; }
QPushButton:disabled { color: #555957; border-color: #292c2b; }
QPushButton#primary { background: #6b3935; border: 1px solid #a3655d; color: #f0dfd4; }
QPushButton#primary:hover { background: #81443e; }
QPushButton#primary:disabled { background: #302424; color: #6c5a57; border-color: #49312e; }
QCheckBox { background: transparent; spacing: 8px; color: #d0cec3; font-weight: bold; }
QCheckBox::indicator { width: 12px; height: 12px; border: 1px solid #66685e; background: #151717; }
QCheckBox::indicator:checked { background: #a36660; border-color: #ca8a7f; }
QSlider { background: transparent; min-height: 22px; }
QSlider::groove:horizontal { height: 3px; background: #353735; }
QSlider::sub-page:horizontal { background: #925c56; }
QSlider::handle:horizontal { background: #c3b9a6; width: 8px; margin: -5px 0; border-radius: 0px; }
QScrollArea { border: none; background: #171819; }
QScrollBar:vertical { background: #141616; width: 8px; }
QScrollBar::handle:vertical { background: #4c4d47; min-height: 25px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QSplitter::handle { background: #0b0c0d; width: 8px; }
QGraphicsView { border: 1px solid #343734; background: #080a0a; }
QToolTip { background: #242625; color: #d7d1c3; border: 1px solid #66675e; }
'''


def label(text, role=None, wrap=False):
    widget = QLabel(text)
    if role:
        widget.setObjectName(role)
    widget.setWordWrap(wrap)
    return widget


def panel():
    widget = QFrame()
    widget.setObjectName('panel')
    layout = QVBoxLayout(widget)
    layout.setContentsMargins(16, 16, 16, 16)
    layout.setSpacing(14)
    return widget, layout


def button(text, callback, primary=False):
    widget = QPushButton(text)
    widget.clicked.connect(callback)
    if primary:
        widget.setObjectName('primary')
    widget.setCursor(Qt.CursorShape.PointingHandCursor)
    return widget


class Job(QThread):
    completed = Signal(object)
    failed = Signal(str)

    def __init__(self, operation, parent):
        super().__init__(parent)
        self.operation = operation

    def run(self):
        try:
            self.completed.emit(self.operation())
        except Exception as exc:
            self.failed.emit(f'{type(exc).__name__}: {exc}')


class Preview(QGraphicsView):
    """Scene holds only display pixels. Export always uses the full render."""
    zoom_changed = Signal(str)

    def __init__(self):
        super().__init__()
        self.setScene(QGraphicsScene(self))
        self.item = self.scene().addPixmap(QPixmap())
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        self.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.fit_mode = True
        self.image_scale = 1.0

    def set_image(self, image):
        display = image.copy()
        display.thumbnail((2400, 2400))
        self.image_scale = image.width / display.width
        data = display.convert('RGBA').tobytes()
        qimage = QImage(data, display.width, display.height,
                        display.width * 4, QImage.Format.Format_RGBA8888).copy()
        self.item.setPixmap(QPixmap.fromImage(qimage))
        self.scene().setSceneRect(self.item.boundingRect())
        if self.fit_mode:
            self.fit_image()
        else:
            self.report_zoom()

    def fit_image(self):
        self.fit_mode = True
        if not self.item.pixmap().isNull():
            self.fitInView(self.item, Qt.AspectRatioMode.KeepAspectRatio)
        self.report_zoom()

    def zoom(self, factor):
        if self.item.pixmap().isNull():
            return
        current = self.transform().m11() / self.image_scale
        target = min(8.0, max(.02, current * factor))
        self.fit_mode = False
        self.scale(target / current, target / current)
        self.report_zoom()

    def report_zoom(self):
        self.zoom_changed.emit(f'{self.transform().m11() / self.image_scale:.0%}')

    def wheelEvent(self, event):
        self.zoom(1.2 if event.angleDelta().y() > 0 else 1 / 1.2)
        event.accept()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self.fit_mode:
            self.fit_image()

    def drawForeground(self, painter, rect):
        # Screen-space CRT detail; this overlay never enters exported pixels.
        painter.save()
        painter.resetTransform()
        painter.setPen(QPen(QColor(0, 0, 0, 16), 1))
        for y in range(0, self.viewport().height(), 4):
            painter.drawLine(0, y, self.viewport().width(), y)
        if self.item.pixmap().isNull():
            painter.setPen(QColor('#85877b'))
            painter.drawText(self.viewport().rect(), Qt.AlignmentFlag.AlignCenter,
                             'NO SIGNAL\n\nLOAD AN IMAGE TO ESTABLISH INPUT\n\nJPG / PNG / BMP')
        painter.restore()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('NULL//SIGNAL — Analog image processor')
        self.resize(1400, 900)
        self.setMinimumSize(1000, 680)
        self.original = self.processed = None
        self.source_path = None
        self.seed = random.randrange(2**31)
        self.revision = 0
        self.rendered_revision = -1
        self.worker = None
        self.pending = False
        self.closing = False
        self.controls = {}
        self.debounce = QTimer(self)
        self.debounce.setSingleShot(True)
        self.debounce.setInterval(220)
        self.debounce.timeout.connect(self.request_render)
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(22, 18, 22, 18)
        layout.setSpacing(16)
        top = QHBoxLayout()
        brand = QVBoxLayout()
        brand.addWidget(label('NULL//SIGNAL', 'logo'))
        brand.addWidget(label('EXPERIMENTAL IMAGE PROCESSING TERMINAL', 'muted'))
        top.addLayout(brand)
        top.addStretch()
        self.system_status = label('SYSTEM STATUS  //  STANDBY', 'red')
        top.addWidget(self.system_status)
        top.addSpacing(25)
        self.image_status = label('INPUT: NONE', 'muted')
        top.addWidget(self.image_status)
        top.addSpacing(25)
        top.addWidget(label(f'v{VERSION}', 'muted'))
        layout.addLayout(top)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        left, ll = panel()
        left.setMinimumWidth(190)
        ll.addWidget(label('01 / SOURCE', 'muted'))
        self.load_button = button('LOAD IMAGE', self.choose_image)
        ll.addWidget(self.load_button)
        self.file_label = label('NO INPUT FILE', wrap=True)
        ll.addWidget(self.file_label)
        self.info_label = label('DIMENSIONS  —\nFORMAT      —\nMODE        —', 'muted', True)
        ll.addWidget(self.info_label)
        ll.addStretch()
        ll.addWidget(label('SOURCE PROTECTION / ON', 'red', True))
        ll.addWidget(label('All operations use a copy.\nOriginal pixels are retained.', 'muted', True))
        ll.addSpacing(24)
        ll.addWidget(label('SYSTEM TRANSMISSION', 'muted'))
        self.message = label('', 'red', True)
        self.quote = label('', 'muted', True)
        ll.addWidget(self.message)
        ll.addWidget(self.quote)
        ll.addWidget(button('SYSTEM LOG  ↗', self.change_message))
        splitter.addWidget(left)

        center = QWidget()
        cl = QVBoxLayout(center)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(10)
        toolbar = QHBoxLayout()
        self.group = QButtonGroup(self)
        self.before_button = button('BEFORE', self.show_preview)
        self.after_button = button('AFTER', self.show_preview)
        for b in (self.before_button, self.after_button):
            b.setCheckable(True)
            self.group.addButton(b)
            toolbar.addWidget(b)
        self.after_button.setChecked(True)
        toolbar.addStretch()
        self.preview = Preview()
        toolbar.addWidget(button('FIT', self.preview.fit_image))
        toolbar.addWidget(button('−', lambda: self.preview.zoom(1 / 1.25)))
        self.zoom_label = label('100%', 'muted')
        toolbar.addWidget(self.zoom_label)
        toolbar.addWidget(button('+', lambda: self.preview.zoom(1.25)))
        self.preview.zoom_changed.connect(self.zoom_label.setText)
        cl.addLayout(toolbar)
        cl.addWidget(self.preview, 1)
        self.preview_status = label('MONITOR 01  //  AWAITING INPUT', 'muted')
        cl.addWidget(self.preview_status)
        splitter.addWidget(center)

        right, rl = panel()
        right.setMinimumWidth(275)
        rl.addWidget(label('02 / SIGNAL CHAIN', 'muted'))
        rl.addWidget(label('Enable a channel. Adjust its intensity.', 'muted', True))
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        content.setStyleSheet('background: #171819;')
        effects_layout = QVBoxLayout(content)
        effects_layout.setContentsMargins(0, 0, 8, 0)
        effects_layout.setSpacing(15)
        for index, (name, description) in enumerate(EFFECTS.items(), 1):
            row = QVBoxLayout()
            row.setSpacing(5)
            check = QCheckBox(name)
            check.setToolTip(description)
            row.addWidget(check)
            row.addWidget(label(description, 'muted', True))
            value_row = QHBoxLayout()
            slider = QSlider(Qt.Orientation.Horizontal)
            slider.setRange(0, 100)
            slider.setValue(50)
            slider.setEnabled(False)
            slider.setAccessibleName(f'{name} intensity')
            number = label('050', 'muted')
            number.setMinimumWidth(28)
            slider.value_label = number
            value_row.addWidget(slider)
            value_row.addWidget(number)
            row.addLayout(value_row)
            effects_layout.addLayout(row)
            self.controls[name] = check, slider
            check.toggled.connect(slider.setEnabled)
            check.toggled.connect(self.settings_changed)
            slider.valueChanged.connect(lambda v, n=number: n.setText(f'{v:03d}'))
            slider.valueChanged.connect(self.settings_changed)
        effects_layout.addStretch()
        scroll.setWidget(content)
        rl.addWidget(scroll, 1)
        splitter.addWidget(right)
        splitter.setSizes([220, 800, 300])
        splitter.setStretchFactor(1, 1)
        layout.addWidget(splitter, 1)
        bottom = QHBoxLayout()
        self.process_button = button('PROCESS IMAGE', self.request_render, True)
        self.random_button = button('RANDOMIZE', self.randomize)
        self.reset_button = button('RESET', self.reset)
        self.export_button = button('EXPORT IMAGE', self.choose_export)
        for b in (self.process_button, self.random_button, self.reset_button):
            bottom.addWidget(b)
        bottom.addStretch()
        self.seed_label = label(f'SIGNAL SEED / {self.seed:010d}', 'muted')
        bottom.addWidget(self.seed_label)
        bottom.addSpacing(16)
        bottom.addWidget(self.export_button)
        layout.addLayout(bottom)
        self.change_message()
        self.message_timer = QTimer(self)
        self.message_timer.timeout.connect(self.change_message)
        self.message_timer.start(45000)
        self.update_buttons()

    def change_message(self):
        self.message.setText(random.choice(MESSAGES))
        self.quote.setText('“' + random.choice(QUOTES) + '”')

    def settings(self):
        return {name: slider.value() if check.isChecked() else 0
                for name, (check, slider) in self.controls.items()}

    def settings_changed(self, *_):
        self.revision += 1
        if self.original is not None:
            self.preview_status.setText('SETTINGS CHANGED  //  RENDER PENDING')
            self.debounce.start()
        self.update_buttons()

    def update_buttons(self):
        loaded = self.original is not None
        idle = self.worker is None
        self.load_button.setEnabled(idle and not self.closing)
        self.process_button.setEnabled(loaded and idle)
        self.random_button.setEnabled(loaded)
        self.reset_button.setEnabled(loaded)
        self.export_button.setEnabled(loaded and idle and self.rendered_revision == self.revision)

    def start_job(self, operation, success, status):
        self.system_status.setText('SYSTEM STATUS  //  ' + status)
        worker = Job(operation, self)
        self.worker = worker
        worker.completed.connect(success)
        worker.failed.connect(self.job_error)
        worker.finished.connect(self.job_finished)
        self.update_buttons()
        worker.start()

    def job_error(self, detail):
        self.system_status.setText('SYSTEM STATUS  //  ERROR')
        if not self.closing:
            QMessageBox.warning(self, 'Operation failed',
                                'The operation could not be completed.\n\n' + detail)

    def job_finished(self):
        worker = self.worker
        self.worker = None
        worker.deleteLater()
        if self.closing:
            self.close()
            return
        self.update_buttons()
        if self.pending:
            self.pending = False
            self.request_render()
        elif 'ERROR' not in self.system_status.text():
            self.system_status.setText('SYSTEM STATUS  //  READY')

    def choose_image(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Establish image input', '',
                                            'Images (*.jpg *.jpeg *.png *.bmp);;All files (*)')
        if path:
            self.load_path(path)

    def load_path(self, path):
        if self.worker is not None:
            return
        self.debounce.stop()
        self.pending = False
        self.start_job(lambda: load_image(path),
                       lambda result: self.image_loaded(path, result), 'READING INPUT')

    def image_loaded(self, path, result):
        self.original, fmt = result
        self.source_path = Path(path)
        self.revision += 1
        self.processed = self.original.copy()
        self.rendered_revision = self.revision if not any(self.settings().values()) else -1
        self.file_label.setText(self.source_path.name)
        w, h = self.original.size
        self.info_label.setText(f'DIMENSIONS\n{w:,} × {h:,} px\n\nFORMAT / {fmt}\nMODE / RGBA')
        self.image_status.setText(f'INPUT: {w} × {h}')
        self.preview.fit_mode = True
        self.show_preview()
        self.preview_status.setText('INPUT ESTABLISHED  //  SOURCE PROTECTED')
        self.pending = any(self.settings().values())
        self.change_message()

    def request_render(self):
        self.debounce.stop()
        if self.original is None:
            QMessageBox.information(self, 'No input', 'Load an image before processing.')
            return
        if self.worker is not None:
            self.pending = True
            return
        self.pending = False
        source, settings, seed, revision = self.original, self.settings(), self.seed, self.revision
        self.start_job(lambda: process_image(source, settings, seed),
                       lambda image: self.render_complete(image, revision), 'PROCESSING')

    def render_complete(self, image, revision):
        # Discard stale work rather than displaying a render for old settings.
        if revision != self.revision:
            self.pending = True
            return
        self.processed = image
        self.rendered_revision = revision
        self.show_preview()
        active = sum(value > 0 for value in self.settings().values())
        self.preview_status.setText(f'MONITOR 01  //  {active:02d} CHANNELS ACTIVE  //  FULL RESOLUTION')

    def show_preview(self):
        image = self.original if self.before_button.isChecked() else self.processed
        if image is not None:
            self.preview.set_image(image)

    def set_controls(self, values):
        for name, (check, slider) in self.controls.items():
            check.blockSignals(True)
            slider.blockSignals(True)
            enabled = name in values
            check.setChecked(enabled)
            slider.setValue(values.get(name, 50))
            slider.setEnabled(enabled)
            slider.blockSignals(False)
            check.blockSignals(False)
            slider.value_label.setText(f'{slider.value():03d}')
        self.settings_changed()

    def randomize(self):
        names = random.sample(list(EFFECTS), random.randint(2, 4))
        self.seed = random.randrange(2**31)
        self.seed_label.setText(f'SIGNAL SEED / {self.seed:010d}')
        self.set_controls({name: random.randint(20, 85) for name in names})
        self.after_button.setChecked(True)
        self.change_message()
        self.request_render()

    def reset(self):
        self.set_controls({})
        self.request_render()

    def choose_export(self):
        if self.processed is None or self.rendered_revision != self.revision or self.worker is not None:
            QMessageBox.information(self, 'Image not ready', 'Load and process an image before exporting.')
            return
        default = str(self.source_path.with_name(self.source_path.stem + '_null_signal.png'))
        path, selected = QFileDialog.getSaveFileName(
            self, 'Export signal', default, 'PNG (*.png);;JPEG (*.jpg *.jpeg);;BMP (*.bmp)')
        if not path:
            return
        if not Path(path).suffix:
            path += '.jpg' if selected.startswith('JPEG') else '.bmp' if selected.startswith('BMP') else '.png'
        # QFileDialog may not confirm an existing path after adding an extension.
        if Path(path).exists():
            answer = QMessageBox.question(self, 'Replace export?',
                                          'This destination already exists. Replace it?')
            if answer != QMessageBox.StandardButton.Yes:
                return
        image, source = self.processed, self.source_path
        self.start_job(lambda: export_image(image, path, source),
                       lambda _: self.preview_status.setText('EXPORT COMPLETE  //  ' + Path(path).name),
                       'EXPORTING')

    def closeEvent(self, event):
        if self.worker is not None:
            self.closing = True
            self.debounce.stop()
            self.pending = False
            self.centralWidget().setEnabled(False)
            self.system_status.setText('SYSTEM STATUS  //  FINISHING OPERATION')
            event.ignore()
        else:
            event.accept()


def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    app.setStyleSheet(STYLE)
    app.setFont(QFont('Consolas', 10))
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
